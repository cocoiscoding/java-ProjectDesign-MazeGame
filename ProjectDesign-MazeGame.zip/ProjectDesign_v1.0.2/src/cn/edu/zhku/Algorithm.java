package cn.edu.zhku;

import java.io.*;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class Algorithm {
    protected static int m, n;// These are used to copy the values of MazeDesign.m and MazeDesign.n
    protected static int currentX, currentY;// The mouse's current position
    protected static int startX, startY;// The mouse original position
    // Decide whether the mouse's movements could be changed by using the keyboard. Its original value is false.
    protected static boolean changeableKey = false;
    // Decide whether the game could be restarted. Its original value is false.
    protected static boolean restart = false;
    // Define an array to store the information that whether the block is visited or not
    private static boolean[] isVisited = null;

    /**
     * The algorithm of searching for the shortest path
     */
    @SuppressWarnings("deprecation")
    public static void sortPath() {
        MazeDesign.timeThread.suspend();// Suspend the time thread
        // When searching for the paths, the mouse could not be moved by using the keyboard
        changeableKey = false;
        setEditable(false);// When searching for the paths, the blocks could not be edited
        // Copy the values of rows and columns of the maze
        m = MazeDesign.m;
        n = MazeDesign.n;
        int max = m * n;// The maximum length of every shortest path would not be more than m * n
        // Define an array to store the DFS graph
        int[] depthGraph = new int[m * n];
        // Initialize the graph and set the distance between the granary and itself is absolutely 0
        depthGraph[m * n - 1] = 0;
        // Traverse other blocks
        for (int i = 0; i < m * n - 1; i++) {
            // If the block is a wall which means the mouse could not pass
            if (MazeDesign.mapArray[i / n][i % n].isWall())
                depthGraph[i] = -1;
            else
                depthGraph[i] = max;// Other blocks' distance would be set as 'max'
        }

        boolean flag = true;// Define a flag to check that if the distance were modified
        int currentX, currentY;// The current position
        int aroundMin;// The minimum depth + 1
        // Dynamically update the path depth map until it reaches steady state
        // (i.e. no path depth is modified in the last cycle)
        while (flag) {
            flag = false;// Originally, set the flag into false
            // Traverse the whole graph
            for (int i = m * n - 1; i >= 0; i--) {
                if (depthGraph[i] != -1) {// If the block is not a wall
                    aroundMin = depthGraph[i];
                    // Make the two-dimension spot to the one-dimension one
                    currentX = i / n;
                    currentY = i % n;

                    if (currentY + 1 < n && depthGraph[i + 1] != -1 && depthGraph[i + 1] + 1 < aroundMin) {
                        aroundMin = depthGraph[i + 1] + 1;
                    }

                    if (currentX + 1 < m && depthGraph[i + n] != -1 && depthGraph[i + n] + 1 < aroundMin) {
                        aroundMin = depthGraph[i + n] + 1;
                    }

                    if (currentY - 1 >= 0 && depthGraph[i - 1] != -1 && depthGraph[i - 1] + 1 < aroundMin) {
                        aroundMin = depthGraph[i - 1] + 1;
                    }

                    if (currentX - 1 >= 0 && depthGraph[i - n] != -1 && depthGraph[i - n] + 1 < aroundMin) {
                        aroundMin = depthGraph[i - n] + 1;
                    }

                    if (aroundMin < depthGraph[i]) {
                        depthGraph[i] = aroundMin;
                        flag = true;
                    }
                }
            }
        }

        // Find the shortest path between the mouse and the granary by using the graph
        int[] path = new int[m * n];// Define an array to store the shortest path
        int currentPoint = startX * n + startY;// The mouse's current position
        int depth = depthGraph[currentPoint];// Mouse's depth
        int step = depth - 1;// The current depth of path
        while (step > 0) {
            // Make the two-dimension spot to the one-dimension one
            currentX = currentPoint / n;
            currentY = currentPoint % n;

            if (currentY + 1 < n && depthGraph[currentPoint + 1] == step) {
                currentPoint += 1;
            } else if (currentX + 1 < m && depthGraph[currentPoint + n] == step) {
                currentPoint += n;
            } else if (currentY - 1 >= 0 && depthGraph[currentPoint - 1] == step) {
                currentPoint -= 1;
            } else if (currentX - 1 >= 0 && depthGraph[currentPoint - n] == step) {
                currentPoint -= n;
            }

            path[step--] = currentPoint;
        }

        int tmpPosition;// Define a temporary variable to store position
        for (int i = 1; i < depth; i++) {
            tmpPosition = path[i];// Read data from the array which stores the data of the shortest path
            // Display the shortest path by repeating the mouse image
            MazeDesign.mapArray[tmpPosition / n][tmpPosition % n].change(2);
        }

        restart = true;// Then a new game could be started
    }

    /**
     * Use DFS to search for a path
     */
    @SuppressWarnings("deprecation")
    public static void findPath() {
        MazeDesign.timeThread.suspend();// Suspend the time thread
        changeableKey = false;// When searching for the path, the mouse could not be moved by using the keyboard
        setEditable(false);// When searching for the path, the block could not be edited

        // Copy the values
        m = MazeDesign.m;
        n = MazeDesign.n;
        // Search from the original position
        int currentX = startX;
        int currentY = startY;
        // Define a variable which illustrates the directions
        int direction = 0;// 0 for right, 1 for down, 2 for left, 3 for up
        int distance;// Define a variable which illustrates distance
        int[] point = new int[m * n];
        // Define an array to store information that whether the block is visited
        boolean[] isVisited = new boolean[m * n];
        // Initialize the array
        for (int i = 0; i < m * n - 1; i++)
            isVisited[i] = false;

        int step = 0;
        point[step] = currentX * n + currentY;
        step++;
        for (; ; ) {// Make a dead loop
            if (currentX == m - 1 && currentY == n - 1) {// The mouse has already find the granary
                // 'step - 1' means the granary so that the block could not be repainted
                for (int i = 1; i < step - 1; i++)
                    // Display the path by repeating the mouse image
                    MazeDesign.mapArray[point[i] / n][point[i] % n].change(2);
                restart = true;// Then a new game could be restarted

                return;
            }

            switch (direction) {// Traverse by the sequence of right(0)--down(1)--left(2)--up(3)
                case 0:// Right
                    if ((currentY + 1 < n) && (!MazeDesign.mapArray[currentX][currentY + 1].isWall())
                            && (!isVisited[currentX * n + currentY + 1])) {
                        point[step] = currentX * n + currentY + 1;
                        isVisited[currentX * n + currentY + 1] = true;
                        currentY++;
                        step++;
                        direction = 0;

                    } else
                        direction++;
                    break;
                case 1:// Down
                    if (currentX + 1 < m && !MazeDesign.mapArray[currentX + 1][currentY].isWall()
                            && !isVisited[(currentX + 1) * n + currentY]) {
                        point[step] = (currentX + 1) * n + currentY;
                        isVisited[(currentX + 1) * n + currentY] = true;
                        currentX++;
                        step++;
                        direction = 0;
                    } else
                        direction++;
                    break;
                case 2:// Left
                    if (currentY - 1 >= 0 && !MazeDesign.mapArray[currentX][currentY - 1].isWall()
                            && !isVisited[currentX * n + currentY - 1]) {
                        point[step] = currentX * n + currentY - 1;
                        isVisited[currentX * n + currentY - 1] = true;
                        currentY--;
                        step++;
                        direction = 0;
                    } else
                        direction++;
                    break;
                case 3:// Up
                    if (currentX - 1 >= 0 && !MazeDesign.mapArray[currentX - 1][currentY].isWall()
                            && !isVisited[(currentX - 1) * n + currentY]) {
                        point[step] = (currentX - 1) * n + currentY;
                        isVisited[(currentX - 1) * n + currentY] = true;
                        currentX--;
                        step++;
                        direction = 0;
                    } else
                        direction++;
                    break;
                default:// The road could not pass, then return to the last step to check the direction
                    step--;// Return to the last step
                    isVisited[point[step]] = false;// Set the flag to be 'unvisited'
                    if (step <= 0) {// The maze do not have any road to pass
                        // Display the messages to the player
                        JOptionPane.showMessageDialog(null,
                                "抱歉，该迷宫没有通路，请使用其它迷宫开始新的游戏。",
                                "该迷宫没有通路！",
                                JOptionPane.ERROR_MESSAGE);
                        restart = true;// Then a new game could be started
                        return;
                    }

                    distance = point[step] - point[step - 1];
                    if (distance == 1) {
                        //在上一步的右方向（0），则返回上一步时 再找下一个方向 direction=1   下同
                        currentX = point[step - 1] / n;
                        currentY = point[step - 1] % n;
                        direction = 1;
                    } else if (distance == n) {
                        currentX = point[step - 1] / n;
                        currentY = point[step - 1] % n;
                        direction = 2;
                    } else if (distance == -1) {
                        currentX = point[step - 1] / n;
                        currentY = point[step - 1] % n;
                        direction = 3;
                    } else {
                        direction = 4;// Continue to go back
                    }
            }
        }
    }

    /**
     * Traverse the maze and find more than one random path by using DFS
     */
    public static void traverseMaze() {
        // Copy
        m = MazeDesign.m;
        n = MazeDesign.n;
        // Before traversing, create and initialize the array which is used to store the info whether
        // the block is visited or not
        isVisited = new boolean[m * n];
        for (int i = 0; i < m * n; i++)
            isVisited[i] = false;

        // Initialize the maze and ake sure that the borders would not be walls at the same time
        // For rows
        for (int i = 0; i < m; i++) {// Make sure that the borders would not be walls at the same time
            // Change walls into roads by changing the 'flag'
            MazeDesign.mapArray[i][0].change(Math.random() * 3 > 1 ? 0 : 1);
            MazeDesign.mapArray[i][n - 1].change(Math.random() * 3 > 1 ? 0 : 1);
        }

        // For columns
        for (int i = 0; i < n; i++) {
            MazeDesign.mapArray[0][i].change(Math.random() * 3 > 1 ? 0 : 1);
            MazeDesign.mapArray[m - 1][i].change(Math.random() * 3 > 1 ? 0 : 1);
        }

        // Use a double for-loop to traverse the whole maze
        for (int i = 1; i < m - 1; i++)
            for (int j = 1; j < n - 1; j++)
                // Set other blocks all into walls
                MazeDesign.mapArray[i][j].change(0);

        // The mouse's original position should be in the center of the maze
        startX = m / 2;
        startY = n / 2;

        /*
        startX = (int) (Math.random() * m / 2);
        startY = (int) (Math.random() * n / 2);    //随机生成老鼠位置
         */

        // Traverse the graph by using DFS from the mouse's original position
        // 从老鼠位置开始深度优先遍历与它x 、y坐标相差均为偶数的点构成的图
        dfsTraverse(startX * n + startY);

        if (Math.random() * 2 > 1)
            MazeDesign.mapArray[m - 2][n - 1].change(1);
        else
            MazeDesign.mapArray[m - 1][n - 2].change(1);    //两者只要有一个为路即可，故随机取其一

        // Set the position of mouse and granary
        MazeDesign.mapArray[startX][startY].change(2);// mouse
        MazeDesign.mapArray[m - 1][n - 1].change(3);// granary

        changeableKey = false;// When searching for the paths, the mouse could not be moved by using the keyboard
        // Before starting a new game, mouse's current position would be set to its original position
        currentX = startX;
        currentY = startY;
        restart = false;// When searching for the paths, players could not restart a new game
    }

    /**
     * Use DFS to traverse the maze
     * @param s mouse's current position
     */
    public static void dfsTraverse(int s) {
        MazeDesign.mapArray[s / n][s % n].change(1);// Turn the current block into a wall
        isVisited[s] = true;// Then sign it into a visited one
        // Define a sequence array to store the directions
        int[] direction = new int[4];// 0 for right, 1 for down, 2 for left, 3 for up
        boolean[] isStored = new boolean[4];// Define an array to store info that if the block is stored
        // Initialize the array
        for (int i = 0; i < 4; i++)
            isStored[i] = false;

        // Set the actual s
        int currentX = s / n;
        int currentY = s % n;

        int rand;// Define a variable to record the random number
        int length = 0;// 'length' illustrates the number of directions that has been stored
        while (length < 4) {
            rand = (int) (Math.random() * 4);// Create a random number between 0 and 3
            if (!isStored[rand]) {// If this s is not stored(false)
                direction[length++] = rand;
                isStored[rand] = true;// Then set the value as 'true' to prevent repeated record
            }
        }

        // When the value of directions is less than 4
        for (int i = 0; i < 4; i++) {
            switch (direction[i]) {
                case 0:// 0 for right
                    if (currentY + 2 < n) {
                        if (!isVisited[s + 2]) {
                            // Make the walls become roads
                            MazeDesign.mapArray[currentX][currentY + 1].change(1);
                            dfsTraverse(s + 2);// Use recursion to complete DFS algorithm
                        }
                    }
                    break;
                case 1:// 1 for down
                    if (currentX + 2 < m) {
                        if (!isVisited[s + 2 * n]) {
                            // Make the walls become roads
                            MazeDesign.mapArray[currentX + 1][currentY].change(1);
                            dfsTraverse(s + 2 * n);// Recursion
                        }
                    }
                    break;
                case 2: // 2 for left
                    if (currentY - 2 >= 0) {
                        if (!isVisited[s - 2]) {
                            // Make the walls become roads
                            MazeDesign.mapArray[currentX][currentY - 1].change(1);
                            dfsTraverse(s - 2);// Recursion
                        }
                    }
                    break;
                case 3:// 3 for up
                    if (currentX - 2 >= 0) {
                        if (!isVisited[s - 2 * n]) {
                            // Make the walls become roads
                            MazeDesign.mapArray[currentX - 1][currentY].change(1);
                            dfsTraverse(s - 2 * n);// Recursion
                        }
                    }

                    break;
                }
            }
    }

    /**
     * Start the game
     */
    @SuppressWarnings("deprecation")
    public static void start() {
        // If the game could be restarted, then call the method to traverse the maze
        if (restart)
            traverseMaze();

        MazeDesign.leftTime = MazeDesign.timeLimit;// Reset the time limit
        MazeDesign.timeThread.resume();// Resume the time thread
        changeableKey = true;// When the game started, players could use keyboard to move the mouse
        setEditable(false);// When the game started, the blocks could not be edited by players
    }

    /**
     * Set time limit
     */
    @SuppressWarnings("deprecation")
    public static void setTime() {
        int time;// Define a variable to record time
        String timeStr;// Define a string to help display the messages
        try {
            // Give some tips to players
            timeStr = JOptionPane.showInputDialog("请输入最大时间限制（单位为秒)：\n提示：输入0代表无时间限制）");
            time = Integer.parseInt(timeStr);// Get time from the console
            if (time < 0) // If players enter an illegal time, the throws exception
                throw new Exception();

            MazeDesign.timeLimit = time;// Reset the time limit
            // Make some tips for players
            Object[] options = {"新游戏", "当前游戏", "取消"};
            int response = JOptionPane.showOptionDialog(null,
                    "请选择是否开始新游戏还是重新玩当前游戏",
                    "游戏时间设置成功",
                    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            // If players choose to cancel
            if(response == JOptionPane.CANCEL_OPTION)
                return;

            // If players choose to restart the game
            if (response == 0) {
                restart = true;
                start();// Start the game
            } else if (response == 1) {// If players choose to continue to play the current game
                MazeDesign.mapArray[currentX][currentY].change(1);// Turn the block to 'road'
                // Reset the current position, make the mouse back to the original position
                currentX = startX;
                currentY = startY;
                MazeDesign.mapArray[currentX][currentY].change(2);// Turn the block to 'mouse'
                restart = false;// When setting the time, players could not restart the game
                start();// Start a new game
            }
        } catch (Exception e) {
            // If players enter an illegal number, then display messages to tell players the error
            JOptionPane.showMessageDialog(null,
                    "由于用户取消或输入不符合要求等原因，游戏时间限定设置失败。",
                    "未更改游戏时间限制",
                    JOptionPane.ERROR_MESSAGE);
            MazeDesign.timeThread.resume(); //  Resume the time thread
        }
    }

    /**
     * Save the maze file
     */
    @SuppressWarnings("deprecation")
    public static void saveMazeFile() {
        MazeDesign.timeThread.suspend();// Suspend the time thread
        JFileChooser jFile = new JFileChooser();// Make a file chooser to choose file
        jFile.setFileSelectionMode(JFileChooser.FILES_ONLY);// Set the mode of file selection
        jFile.showSaveDialog(null);// Save the file
        File file = jFile.getSelectedFile();// Choose the file

        if (file.exists()) {// If the chosen file is existed
            int answer = JOptionPane.showConfirmDialog(null,
                    "文件已存在，是否覆盖保存？",
                    "文件已存在",
                    JOptionPane.YES_NO_CANCEL_OPTION);
            // If players click NO or CANCEL, then quit
            if (answer != JOptionPane.YES_OPTION)
                return;
        }

        try {
            String filePath = file.getAbsolutePath();// Define a string to store the absolute path of the file
            // Here the file should be allowed to be read and written
            RandomAccessFile out = new RandomAccessFile(filePath, "rw");
            out.writeInt(m);
            out.writeInt(n);
            // Use a double for-loop to traverse the maze
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    if (i == startX && j == startY)// Keep the mouse's original position
                        out.writeInt(2);
                    else if (MazeDesign.mapArray[i][j].getFlag() == 2)
                        out.writeInt(1);// Make other blocks turn to roads
                    else// Write other data in the file
                        out.writeInt(MazeDesign.mapArray[i][j].getFlag());
                }
            }

            out.close();
        } catch (Exception e) {
            // If players cancel the operation or the file path is wrong, then give tips to players
            JOptionPane.showMessageDialog(null,
                    "未能保存文件，可能是用户取消或文件路径有误！",
                    "错误提示",
                    JOptionPane.ERROR_MESSAGE);
        } finally {
            MazeDesign.timeThread.resume(); // Resume the time thread
        }
    }

    //老鼠的移动  只有往右走和往下走才有可能到粮仓，因此只检测这两种情况是否成功进入粮仓

    /**
     * Move the mouse down
     */
    public static void down() {
        // If the mouse could not be moved by using the keyboard, then quit
        if (!changeableKey)
            return;

        // If the mouse has already reached the granary, which means players win, then return
        if (currentX == m - 1 && currentY == n - 1)
            return;

        // If the mouse is next to the granary
        if (currentX + 1 == m - 1 && currentY == n - 1) {
            MazeDesign.mapArray[currentX][currentY].change(1);// Change the block into 'road'
            currentX++;// Move the mouse down
            restart = true;// Then the game could be restarted
            // After moving the mouse to the granary, give tips to players
            int answer = JOptionPane.showConfirmDialog(null,
                    "恭喜你帮助老鼠成功进入粮仓，是否开始新的游戏。",
                    "成功进入粮仓！",
                    JOptionPane.YES_NO_OPTION);
            if (answer == JOptionPane.YES_OPTION)
                start();
        } else if (currentX + 1 < m && !MazeDesign.mapArray[currentX + 1][currentY].isWall()) {
            // When the mouse has not already reached the granary and the upper position is not a wall
            MazeDesign.mapArray[currentX][currentY].change(1);// Change the current block into 'road'
            // Change the lower block into 'mouse' to make it 'move'
            MazeDesign.mapArray[++currentX][currentY].change(2);
        }
    }

    /**
     * Move the mouse up
     */
    public static void up() {
        // If the mouse could not be moved by using the keyboard, then quit
        if (!changeableKey)
            return;

        // If the mouse has already reached the granary, which means players win, then return
        if (currentX == m - 1 && currentY == n - 1)
            return;

        // If the mouse has not already reached the granary and the upper block is not a wall
        if (currentX - 1 >= 0 && !MazeDesign.mapArray[currentX - 1][currentY].isWall()) {
            MazeDesign.mapArray[currentX][currentY].change(1);// Change the current block into 'road'
            // Change the upper block into 'mouse' to make it 'move'
            MazeDesign.mapArray[--currentX][currentY].change(2);
        }
    }

    /**
     * Move the mouse left
     */
    public static void left() {
        // If the mouse could not be moved by using the keyboard, then quit
        if (!changeableKey)
            return;

        // If the mouse has already reached the granary, which means players win, then return
        if (currentX == m - 1 && currentY == n - 1)
            return;

        // If the mouse has not already reached the granary and the right block is not a wall
        if (currentY - 1 >= 0 && !MazeDesign.mapArray[currentX][currentY - 1].isWall()) {
            MazeDesign.mapArray[currentX][currentY].change(1);// Change the current block into 'road'
            // Change the left block into 'mouse' to make it 'move'
            MazeDesign.mapArray[currentX][--currentY].change(2);
        }
    }

    /**
     * Move the mouse right
     */
    public static void right() {
        // If the mouse could not be moved by using the keyboard, then quit
        if (!changeableKey)
            return;

        // If the mouse has already reached the granary, which means players win, then return
        if (currentX == m - 1 && currentY == n - 1)
            return;

        // If the mouse has not already reached the granary and the left block is not a wall
        if (currentX == m - 1 && currentY + 1 == n - 1) {
            MazeDesign.mapArray[currentX][currentY].change(1);// Change the current block into 'road'
            currentY++;// Move the mouse right
            restart = true;// Then the game could be restarted
            // Give some tips
            int answer = JOptionPane.showConfirmDialog(null,
                    "恭喜你帮助老鼠成功进入粮仓，是否开始新的游戏。",
                    "成功进入粮仓！",
                    JOptionPane.YES_NO_OPTION);
            if (answer == JOptionPane.YES_OPTION)
                start();// Restart a new game
        } else if ((currentY + 1 >= 0) && (!MazeDesign.mapArray[currentX][currentY + 1].isWall())) {
            // If the mouse has not already reached the granary and the right block is not a wall
            MazeDesign.mapArray[currentX][currentY].change(1);// Change the block into 'road'
            // Change the right block into 'mouse' to make it 'move'
            MazeDesign.mapArray[currentX][++currentY].change(2);
        }
    }

    /**
     * Set the block if it is editable
     * @param e the parameter illustrates whether the block could be editable
     */
    public static void setEditable(boolean e) {
        // Use a double for-loop to traverse the array
        for (int i = 0; i < m; i++)
            for (int j = 0; j < n; j++)
                MazeDesign.mapArray[i][j].setChangeableClick(e);// Set all the element

        // When editing the maze, mouse's position and the position of granary could not be modified
        MazeDesign.mapArray[m - 1][n - 1].setChangeableClick(false);
        MazeDesign.mapArray[startX][startY].setChangeableClick(false);
    }

    /**
     * Edit maze
     */
    @SuppressWarnings("deprecation")
    public static void editCurrentMaze() {
        MazeDesign.timeThread.suspend();// Suspend the time thread
        changeableKey = false;// When editing the maze, the mouse could not be moved by using the keyboard
        setEditable(true);// When editing the maze, the blocks could be edited
        // Set mouse's current position to the original one to make sure that when the game started, the maze would
        // be the new one
        startX = currentX;
        startY = currentY;
        restart = false;// Then the maze could be restarted
        MazeDesign.timeThread.resume();   // Resume the time thread
    }

    /**
     * Create a random maze
     */
    @SuppressWarnings("deprecation")
    public static void makeRandomMaze() {
        MazeDesign.timeThread.suspend();// Suspend the time thread
        traverseMaze();// Call the method to traverse the maze
        changeableKey = false;// When creating the random maze, the mouse could not be moved by using the keyboard
        setEditable(true);// When creating the random maze, the maze could be editable
        restart = false;// In order to make sure that the edited maze could be used when the new game started
        MazeDesign.timeThread.resume();// Resume the time thread
    }

    /**
     * Display the 'help' contents
     */
    @SuppressWarnings("deprecation")
    public static void showHelp() {
        MazeDesign.timeThread.suspend();// Suspend the time thread
        String help;// Write something about this game maze
        help = "本迷宫游戏非常简单，以下仅作出一些简单的说明：\n"
                + "一、程序启动时的主界面给出3种不同的游戏场地大小供用户选择，用户也可通\n      过点击 自定义 按钮来" +
                "自定义场地大小。\n"
                + "二、进入游戏界面后，游戏所有操作选项都在菜单栏里，\n"
                + "三、开始游戏后，可用方向健控制老鼠的移动。\n"
                + "四、在编辑模式下，可以点击某一块区域使其变为墙或路。\n"
                + "五、除非开始游戏，在其它任何状态下均不可移动老鼠；同样除编辑模式外，其\n     它状态亦不可随意更改墙和路。\n"
                + "六、本程序以二进制文件方式读取和存储迷宫结构,因此，保存和打开文件时最好\n    选用.dat后缀名。\n";
        JOptionPane.showMessageDialog(null, help,
                "游戏使用说明", JOptionPane.INFORMATION_MESSAGE);
        MazeDesign.timeThread.resume();// Resume the time thread
    }

    /**
     * Display the information about author
     */
    @SuppressWarnings("deprecation")
    public static void showAbout() {
        MazeDesign.timeThread.suspend();// Suspend the time thread
        // Display some information about author
        String aboutAuthor = "\t\t仲恺农业工程学院\n\n"
                + "\t\t信息科学与技术学院\n\n"
                + "\t\t计算机194班\n\n"
                + "\t\t郭可珈\n";
        JOptionPane.showMessageDialog(null, aboutAuthor, "关于我们",
                JOptionPane.INFORMATION_MESSAGE);
        MazeDesign.timeThread.resume();// Resume the time thread
    }
}
