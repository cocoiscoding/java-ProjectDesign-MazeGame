package cn.edu.zhku;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.RandomAccessFile;

import javax.swing.*;

@SuppressWarnings("serial")
public class MazeDesign extends JFrame implements ActionListener, KeyListener, Runnable {
    public static int m, n;// Define the values of rows and columns of the maze
    // Here, an array would be used to store the positions of the mouse, the granary, walls and roads
    public static WrmPanel[][] mapArray = null;// To initialize the array, just make every element null
    public static Thread timeThread;// Use multi-thread to control the time of playing
    // 'timeLimit' means the 'deadline' of playing the game
    // 'leftTime' means the time that player would have at that time
    public static int timeLimit, leftTime;
    // Then Define a panel to show the time limit for players
    public static JPanel timePanel = new JPanel() {
        /**
         * Rewrite the 'paintComponent' method to repaint
         * @param g Graphics parameter
         */
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            String rt;// Define a string to store messages
            if (timeLimit == 0) {// When the time limit is infinitive
                rt = "无限制";// Display the messages
                setForeground(new Color(15, 26, 94));// BLUE means the time limit is infinitive
            } else {// When the time limit is NOT infinitive
                // Calculate the remain time
                rt = leftTime / 3600 + " : " + (leftTime - (leftTime / 3600) * 3600) / 60 +
                        " : " + leftTime % 60;
                // If the left time is more than 10 seconds
                if (leftTime > 10)
                    // If players have enough time to play, then the font would be GREEN
                    setForeground(new Color(20, 71, 24));
                else
                    // If players do not have enough time to play, then the font would turn to RED
                    setForeground(new Color(127, 13, 13));
            }

            // Draw the messages on the drawing board
            g.drawString("剩余时间 :  " + rt, 220, 16);
        }
    };

    // Design various functions of the maze game
    private final JMenuItem startNewGame = new JMenuItem("开始新游戏");
    private final JMenuItem setLimitTime = new JMenuItem("设置游戏时间限制");
    private final JMenuItem returnMain = new JMenuItem("返回主界面");
    private final JMenuItem quitGame = new JMenuItem("退出");
    private final JMenuItem saveMaze = new JMenuItem("保存迷宫");
    private final JMenuItem importMaze = new JMenuItem("导入迷宫文件");
    private final JMenuItem editCurrentMaze = new JMenuItem("编辑当前迷宫");
    private final JMenuItem randomMaze = new JMenuItem("随机生成迷宫");
    private final JMenuItem shortestPath = new JMenuItem("显示最短路径");
    private final JMenuItem dfsPath = new JMenuItem("随机生成路径");
    private final JMenuItem helpGame = new JMenuItem("帮助");
    private final JMenuItem aboutGame = new JMenuItem("关于迷宫游戏");


    /**
     * The constructor of class 'MapDesign' to design the maze page
     * @param x the value of rows of the maze
     * @param y the value of columns of the maze
     */
    @SuppressWarnings("deprecation")
    public MazeDesign(int x, int y) {
        m = x;// Rows
        n = y;// Columns
        mapArray = new WrmPanel[m][n];// Decide the two dimensions of the array of the maze
        timeLimit = leftTime = 0;// Initialize the time limit and set the two original values 0
        timeThread = new Thread(this);// Use multi-threads to control the time
        timeThread.start();// Start this multi-thread
        timeThread.suspend();// Suspend this multi-thread

        // Design the menu
        JMenu game = new JMenu("游戏");
        JMenu file = new JMenu("文件");
        JMenu edit = new JMenu("编辑");
        JMenu tip = new JMenu("提示");
        JMenu help = new JMenu("帮助");

        // Then add all the components in the menu according to different types
        game.add(startNewGame);
        game.add(setLimitTime);
        game.add(returnMain);
        game.add(quitGame);
        file.add(saveMaze);
        file.add(importMaze);
        edit.add(editCurrentMaze);
        edit.add(randomMaze);
        tip.add(shortestPath);
        tip.add(dfsPath);
        help.add(helpGame);
        help.add(aboutGame);

        // Then design the menu bar
        JMenuBar menu = new JMenuBar();
        menu.add(game);
        menu.add(file);
        menu.add(edit);
        menu.add(tip);
        menu.add(help);

        // Initialize the maze and create random paths
        // Use a double for-loop to complete assignment
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                // Every elements in the two-dimension array is an instance of class 'WrmPanel'
                mapArray[i][j] = new WrmPanel();
            }
        }

        // Then use DFS algorithm to traverse the maze and create more than one random path
        Algorithm.traverseMaze();
        // Design the map of the maze game
        JPanel mazePanel = new JPanel();// Design a panel for the map
        mazePanel.setLayout(new GridLayout(m, n, 0, 0));// Set the layout of the panel
        // Use a double for-loop to complete assignment
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                // Add all elements of the array in the panel
                mazePanel.add(mapArray[i][j]);
            }
        }

        // Design the whole layout of the maze page
        JPanel northPanel = new JPanel();// Define a panel which would be placed on the north part of the frame
        northPanel.setLayout(new GridLayout(1, 1));// Set the layout of the north panel
        northPanel.add(menu);// Place the menu bar in the north panel
        northPanel.add(timePanel);// Place the panel which displays the time limit in the north panel, too
        // Set the color of background of the two small panels
        timePanel.setBackground(new Color(245, 240, 245));
        menu.setBackground(new Color(245, 240, 245));
        setLayout(new BorderLayout());// Set the layout style of the whole frame
        add(northPanel, BorderLayout.NORTH);// Place the north panel in the north part of the frame
        add(mazePanel, BorderLayout.CENTER);// Place the maze map in the center part of the frame

        // Set some action listeners
        startNewGame.addActionListener(this);
        setLimitTime.addActionListener(this);
        returnMain.addActionListener(this);
        quitGame.addActionListener(this);
        saveMaze.addActionListener(this);
        importMaze.addActionListener(this);
        editCurrentMaze.addActionListener(this);
        randomMaze.addActionListener(this);
        shortestPath.addActionListener(this);
        dfsPath.addActionListener(this);
        helpGame.addActionListener(this);
        aboutGame.addActionListener(this);
        addKeyListener(this);// Add the keyboard listener

        // Some basic settings
        setTitle("迷宫游戏");// Set the title of the maze game
        setSize(800, 800);// Set the size of the frame
        setLocationRelativeTo(null);// Set the position of the window relative to the specified component
        // Set the default action when the user initiates "close" on this form
        // 'JFrame.EXIT_ON_CLOSE' means that exit the application using the system exit method
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);// Make the frame could be visible
        setResizable(true);// Sets whether this page can be resized by the user
    }

    /**
     * Import the maze file to the map
     */
    @SuppressWarnings("deprecation")
    public void importMaze() {
        MazeDesign.timeThread.suspend();// Suspend this time thread
        JFileChooser jFile = new JFileChooser();// Define a file chooser
        jFile.setFileSelectionMode(JFileChooser.FILES_ONLY);// Design the mode of file chooser
        jFile.showOpenDialog(null);// Open the file
        File file = jFile.getSelectedFile();// Choose the file
        try {
            String filePath = file.getAbsolutePath();// Make a string to store the absolute path of the file
            RandomAccessFile in = new RandomAccessFile(filePath, "rw");// Set the mode of file to be 'rw'
            // Then read the values of rows and columns in the file
            int newM = in.readInt();
            int newN = in.readInt();
            // If the new values of rows and columns in the file are different from the ones in the current maze
            if (newM != m || newN != n) {
                dispose();// Then dispose the current maze
                new MazeDesign(newM, newN);// Create a new one with the new values of rows and columns
            }

            int flag;// Define a flag variable
            // Use a double for-loop to traverse the whole two-dimension array
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    flag = in.readInt();// Get the value from reading a signed 32-bit integer from this file
                    // Flag equals 2 means that this block is a road
                    if (flag == 2) {
                        // Set the mouse's original position
                        Algorithm.startX = i;
                        Algorithm.startY = j;
                        // Set the mouse's currents position
                        Algorithm.currentX = i;
                        Algorithm.currentY = j;
                    }

                    // If the flag does not equals 2, which means this block is a wall, mouse or granary
                    // Then change the value of the flag in this block
                    mapArray[i][j].change(flag);
                }
            }

            in.close();// Close
            repaint();// Repaint the drawing board
            // Display the messages and options for players when they try to import maze files
            int answer = JOptionPane.showConfirmDialog(null,
                    "文件中的迷宫结构已导入成功，是否开始游戏？", "文件导入成功！",
                    JOptionPane.YES_NO_CANCEL_OPTION);
            // When players click the YES button, then start the new game
            if (answer == JOptionPane.YES_OPTION)
                Algorithm.start();
        } catch (Exception e) {
            // If the maze file could not be imported, then display the messages for players
            JOptionPane.showMessageDialog(null,
                    "导入迷宫结构失败，可能是用户取消或文件不存在、文件数据有误等原因造成的。",
                    "错误提示",
                    JOptionPane.ERROR_MESSAGE);
        }

        Algorithm.changeableKey = false;// The mouse could not be moved by using keyboard while importing
        Algorithm.restart = false;// Make sure that the new imported maze would be used when the game starts
    }

    /**
     * Rewrite the 'run()' method to control the time limit
     */
    public void run() {
        // The time limit should be more than 0 second
        if (timeLimit > 0) {
            while (true) {// Make a dead loop
                try {
                    // Make the thread sleep 1000 millis in every loop, this may be busy-waiting
                    Thread.sleep(1000);
                    // When the left time is more than 0 which means players would have enough time to play
                    if (leftTime > 0)
                        leftTime--;// Reduce the left time

                    timePanel.repaint();// Repaint the time panel in every loop
                    if (leftTime == 0) {// When players have no time to play games
                        // If the mouse has not reached the granary, then the player lose the game
                        if (Algorithm.currentX != m - 1 || Algorithm.currentY != n - 1) {
                            // Give the player some tips
                            Object[] options = {"新游戏", "重来一次", "取消游戏"};
                            int response = JOptionPane.showOptionDialog(this,
                                    "很遗憾，你没有在限制的时间里完成任务，可怜的小老鼠已经饿死了" +
                                            "\n请选择开始新的游戏，或重玩此游戏",
                                    "游戏超时！",
                                    JOptionPane.YES_NO_CANCEL_OPTION,
                                    JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                            // If the player choose 'CANCEL', then quit the game
                            if(response == JOptionPane.CANCEL_OPTION) {
                                return;
                            }

                            // If the player choose to start a new game, then start a new game
                            if (response == 0) {
                                Algorithm.restart = true;
                                Algorithm.start();
                            } else {// If the player choose to try a again
                                leftTime = timeLimit;// Reset the left time
                                // Make the current block into a road
                                mapArray[Algorithm.currentX][Algorithm.currentY].change(1);
                                // Reset the current position to the start one
                                Algorithm.currentX = Algorithm.startX;
                                Algorithm.currentY = Algorithm.startY;
                                // After resetting the current position, then make the current block into the mouse
                                // which means place the mouse into the original position when the game started
                                mapArray[Algorithm.currentX][Algorithm.currentY].change(2);
                            }
                        }
                    }
                } catch (Exception e) {
                    // If the upper statements throws some exceptions, then print the stack trace
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Deal with the menu events
     * @param e the parameter of event
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startNewGame) {
            Algorithm.start();// Start a new game
        } else if (e.getSource() == returnMain) {
            dispose();// Dispose(close) the current page
            new StartUI();// Return to the main page
        } else if (e.getSource() == dfsPath) {
            Algorithm.findPath();// Display a random path
        } else if (e.getSource() == quitGame) {
            System.exit(0);// Quit the game
        } else if (e.getSource() == editCurrentMaze) {
            Algorithm.editCurrentMaze();// Edit current maze
        } else if (e.getSource() == randomMaze) {
            Algorithm.makeRandomMaze();// Create a random maze
        } else if (e.getSource() == helpGame) {
            Algorithm.showHelp();
        } else if (e.getSource() == shortestPath) {
            Algorithm.sortPath();// Display the shortest path
        } else if (e.getSource() == aboutGame) {
            Algorithm.showAbout();// Display the information about author
        } else if (e.getSource() == saveMaze) {
            Algorithm.saveMazeFile();// Save the maze file
        } else if (e.getSource() == importMaze) {
            importMaze();// Import the maze file
        } else if (e.getSource() == setLimitTime) {
            Algorithm.setTime();// Set time limit
        }
    }

    public void keyTyped(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    /**
     * Deal with the events when the keyboard pressed
     * @param e the parameter of events
     */
    public void keyPressed(KeyEvent e) {
        // According to the result that the integer keyCode associated with the key in this event
        // then call the relevant methods
        switch (e.getKeyCode()) {
            case KeyEvent.VK_DOWN:// Down
                Algorithm.down();
                break;
            case KeyEvent.VK_UP:// Up
                Algorithm.up();
                break;
            case KeyEvent.VK_LEFT:// Left
                Algorithm.left();
                break;
            case KeyEvent.VK_RIGHT:// Right
                Algorithm.right();
                break;
        }
    }
}

