package cn.edu.zhku;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

@SuppressWarnings("serial")
public class StartUI extends JFrame implements ActionListener {
    // Define an instance of ImageIcon to show the image when the game is started
    private final ImageIcon uiMouse = new ImageIcon("src/cn/edu/zhku/UIMouse.gif");
    // Then define four buttons for players to decide which size of maze they would like to play
    private final JButton button1 = new JButton("15 X 15", uiMouse);
    private final JButton button2 = new JButton("25 X 25", uiMouse);
    private final JButton button3 = new JButton("40 X 40", uiMouse);
    private final JButton button4 = new JButton("自定义", uiMouse);
    // Then define the font style of the text in the page
    private final static Font font =new Font("华文行楷",Font.PLAIN,15);

    /**
     * Set the styles of the buttons
     * @param b the button
     */
    public static void setButtonStyles(JButton b) {
        // The style of the button could be visible
        b.setVisible(true);
        // The button is set to be transparent so that it doesn't block the background behind it
        b.setOpaque(false);
        // The setting of removing the border of button in JButton in order to make the button better looking
        b.setContentAreaFilled(true);
        b.setFont(font);// Set the font style for the text in the button
        b.setBorder(BorderFactory.createRaisedBevelBorder());// Make the button appear convex effect
    }

    /**
     * The constructor for the class 'StartUI'
     */
    public StartUI() {
        JPanel choose = new JPanel();// Define a panel to place the buttons
        // Design 2 rows and 2 columns for the layout of the panel
        choose.setLayout(new GridLayout(2, 2));
        // Then add four buttons in the panel
        choose.add(button1);
        choose.add(button2);
        choose.add(button3);
        choose.add(button4);

        // Then set the styles of the buttons
        setButtonStyles(button1);
        setButtonStyles(button2);
        setButtonStyles(button3);
        setButtonStyles(button4);

        // Add action listener for each button
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button4.addActionListener(this);

        // Then design the panel which would be used to place the message
        JPanel message = new JPanel() {// This is an anonymous inner class
            /**
             * Rewrite the 'paintComponent' method to paint
             * @param g the Graphics parameter
             */
            protected void paintComponent(Graphics g) {
                setSize(300, 300);// Set the size of the panel
                setFont(font);// Set the font style of the text
                g.drawString("请选择迷宫大小 :",
                        40, 40);// Set the content of the message
            }
        };

        // The instance of JFrame is not necessary to be created because the class 'StartUI' is extended from JFrame
        setLayout(new BorderLayout(120, 40));// Set the layout of the panel
        add(choose, BorderLayout.CENTER);// Add the 'choose' panel to the center of the frame
        add(message, BorderLayout.NORTH);// Add the 'message' panel to the north part of the frame
        // Add three anonymous panel to the east, west and south part to the frame to make the page better looking
        add(new JPanel(), BorderLayout.EAST);
        add(new JPanel(), BorderLayout.WEST);
        add(new JPanel(), BorderLayout.SOUTH);

        // Some basic settings
        setTitle("迷宫游戏");// Set the title of the maze game
        setSize(800, 700);// Set the size of the maze game page
        setLocationRelativeTo(null);// Set the position of the window relative to the specified component
        // Set the default action when the user initiates "close" on this form
        // 'JFrame.EXIT_ON_CLOSE' means that exit the application using the system exit method
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);// The frame is set to be transparent so that it doesn't block the background behind it
        setResizable(true);// Sets whether this page can be resized by the user
    }

    /**
     * When the button is clicked the relevant events would be performed
     * @param e the parameter of the event
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button1) {// When click the button 1
            dispose();// Dispose the current page
            new MazeDesign(15, 15);// Create a new maze with the size of 15 x 15
        } else if (e.getSource() == button2) {// When click the button 2
            dispose();// Dispose the current page
            new MazeDesign(25, 25);// Create a new maze with the size of 25 x 25
        } else if (e.getSource() == button3) {// When click the button 3
            dispose();// Dispose the current page
            new MazeDesign(40, 40);// Create a new maze with the size of 40 x 40
        } else {// When click the button 4
            // The button 4 means that you should define the size of the maze by yourself so that it decides on the
            // data you enter. Then call the 'getData()' method.
            getData();
        }
    }

    /**
     * Get the data which decides the size of the maze by player himself
     */
    public void getData() {
        int m, n;// m equals the row of the new maze, n equals the column of the new maze
        String crowString;// Define a string which stores messages
        // Use a try-catch statement to prevent throwing exceptions
        try {
            crowString = JOptionPane.showInputDialog("请输入自定义的行数（>5）");
            m = Integer.parseInt(crowString);// Get the new value of row from the console
            crowString = JOptionPane.showInputDialog("请输入自定义的列数（>5）");
            n = Integer.parseInt(crowString);// Get the new value of column from the console
            if (m <= 5 || n <= 5)//// When player enter an illegal number, then throws exception
                throw new Exception();
            else {// If player enter a legal number
                dispose();// Dispose the current page
                new MazeDesign(m, n);// Create a new maze
            }
        } catch (Exception e) {
            // If the upper statements throws some exceptions, then display the tips to tell the player that
            // he or she might enter an illegal number to create a new maze.
            JOptionPane.showMessageDialog(null,
                    "由于用户取消或输入不符合要求等原因，未正常创建迷宫。",
                    "未创建迷宫！",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * The main method
     * @param args the default parameter
     */
    public static void main(String[] args) {
        // In the main method, just create an instance of class 'StartUI' is ok, because it would start the
        // game and call everything up.
        new StartUI();
    }
}
