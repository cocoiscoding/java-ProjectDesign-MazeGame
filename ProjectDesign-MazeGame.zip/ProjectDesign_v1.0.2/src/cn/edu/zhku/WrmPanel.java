package cn.edu.zhku;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

@SuppressWarnings("serial")
public class WrmPanel extends JPanel implements MouseListener {
    private boolean changeableClick;// Check the click if it is changeable
    private int flag;// Signals: 0 for walls, 1 for roads, 2 for the little mouse, 3 for the granary
    // Then define the image for the four elements:
    private final Image wall = new ImageIcon("src/cn/edu/zhku/wall.jpg").getImage();// Walls
    private final Image road = new ImageIcon("src/cn/edu/zhku/road.jpg").getImage();// Roads
    private final Image mouse = new ImageIcon("src/cn/edu/zhku/mouse.gif").getImage();// The little mouse
    private final Image granary = new ImageIcon("src/cn/edu/zhku/granary.jpg").getImage();// The granary

    /**
     * One of the two constructors for the class 'WrmPanel'
     * @param f flag
     */
    public WrmPanel(int f) {
        flag = f;// Assignment
        // The value of 'flag' could not be changed by the mouse-click when initialized
        changeableClick = false;
        addMouseListener(this);// Add the 'MouseListener' method
    }

    /**
     * Another constructor for the class 'WrmPanel'
     */
    public WrmPanel() {
        this(0);// Call the former constructor's method
    }

    /**
     * Rewrite 'paintComponent' method to draw pictures for the maze
     * @param g Graphics parameter
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (flag == 0) {// When 'flag' equals 0, draw the 'wall' in the maze
            g.drawImage(wall, 0, 0, getWidth(), getHeight(), this);
        } else if (flag == 1) {// When 'flag' equals 1, draw the 'road' in the maze
            g.drawImage(road, 0, 0, getWidth(), getHeight(), this);
        } else if (flag == 2) {// When 'flag' equals 2, draw the 'mouse' in the maze
            g.drawImage(mouse, 0, 0, getWidth(), getHeight(), this);
        } else {// When 'flag' equals 3, draw the 'granary' in the maze
            g.drawImage(granary, 0, 0, getWidth(), getHeight(), this);
        }
    }

    /**
     * Get the value of 'flag'
     * @return flag the signal for the maze to decide which picture would be put in the maze
     */
    public int getFlag() {
        return flag;
    }

    /**
     * Check if the block is 'wall'
     * @return flag == 0 : 'flag' equals 0 which means the block is a wall. If 'flag' does not equals 0,
     * which means the block is not a wall.
     */
    public boolean isWall() {
        return flag == 0;
    }

    /**
     * Change the value of 'changeableClick' to set the block whether could be changed or not by one mouse-click
     * @param c a parameter to set the value of 'changeable'
     */
    public void setChangeableClick(boolean c) {
        changeableClick = c;
    }

    /**
     * Change the signal and repaint the maze
     * @param f a parameter to set the value of 'flag'
     */
    public void change(int f) {
        flag = f;
        repaint();
    }

    // Some methods implemented from 'MouseListener' interface are used to deal with mouse-click
    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    /**
     * When edit the structure of the maze, one mouse-click could be used to change the block between
     * wall and road
     * @param e the parameter of MouseEvent
     */
    public void mouseClicked(MouseEvent e) {
        // If the value of 'changeableClick' equals false which means the mouse-click could not change the block
        if (!changeableClick)
            return;

        if (flag == 0) {
            // If the value of 'flag' equals 0 which means the block is a wall now, then a mouse-click could
            // change it into a road which means the value of 'flag' equals 1
            flag = 1;
        } else {
            // If the value of 'flag' equals 1 which means the block is a road now, then a mouse-click could
            // change it into a wall which means the value of 'flag' equals 0
            flag = 0;
        }

        repaint();// After changing the flag, then repaint the block to display a new maze
    }
}